package counter;

public interface SettableCounterType extends CounterType {
	public void setCount(int value);
}

